-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 08 mai 2022 à 11:07
-- Version du serveur : 10.4.22-MariaDB
-- Version de PHP : 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_etudiant`
--

-- --------------------------------------------------------

--
-- Structure de la table `enseignant`
--

CREATE TABLE `enseignant` (
  `id` int(10) UNSIGNED NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `nom` varchar(40) NOT NULL,
  `prenom` varchar(40) NOT NULL,
  `login` varchar(40) NOT NULL,
  `pass` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `enseignant`
--

INSERT INTO `enseignant` (`id`, `date`, `nom`, `prenom`, `login`, `pass`) VALUES
(8, '2022-05-07 16:51:24', 'sonia', 'nouri', 'sonia@gmail.com', '67bbcac48226bdbbeaed6dd47ebd16e2'),
(9, '2022-05-07 16:53:59', 'abir', 'gharsalli', 'abir@gmail.com', '1bbd886460827015e5d605ed44252251');

-- --------------------------------------------------------

--
-- Structure de la table `enseignant_groupe`
--

CREATE TABLE `enseignant_groupe` (
  `id_prof` int(20) NOT NULL,
  `matiere` varchar(40) NOT NULL,
  `classe` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `enseignant_groupe`
--

INSERT INTO `enseignant_groupe` (`id_prof`, `matiere`, `classe`) VALUES
(9, 'SGBD', 'INFO1-D'),
(9, 'SGBD', 'INFO1-E');

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE `etudiant` (
  `cin` int(8) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `cpassword` varchar(40) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `adresse` text NOT NULL,
  `Classe` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`cin`, `email`, `password`, `cpassword`, `nom`, `prenom`, `adresse`, `Classe`) VALUES
(11111111, 'abir@gmail.com', 'bae5e3208a3c700e3db642b6631e95b9', 'bae5e3208a3c700e3db642b6631e95b9', 'abir', 'gharsalli', '     nabeul ', 'INFO1-D'),
(11627227, 'nouri.sonia125@gmail.com', 'dd4b21e9ef71e1291183a46b913ae6f2', 'dd4b21e9ef71e1291183a46b913ae6f2', 'sonia', 'nouri', 'sidi bouzid', 'INFO1-D'),
(77777777, 'y@gmail.com', 'f638f4354ff089323d1a5f78fd8f63ca', 'f638f4354ff089323d1a5f78fd8f63ca', 'y', 'y', '     tunis', 'INFO1-B'),
(88888888, 'z@gmail.com', '8ddcff3a80f4189ca1c9d4d902c3c909', '8ddcff3a80f4189ca1c9d4d902c3c909', 'z', 'z', '     tunis', 'INFO1-B');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `enseignant`
--
ALTER TABLE `enseignant`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `enseignant_groupe`
--
ALTER TABLE `enseignant_groupe`
  ADD PRIMARY KEY (`id_prof`,`matiere`,`classe`);

--
-- Index pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD PRIMARY KEY (`cin`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `enseignant`
--
ALTER TABLE `enseignant`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
